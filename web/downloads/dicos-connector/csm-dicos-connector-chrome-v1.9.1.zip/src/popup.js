const DEFAULT_CSM_URL = "https://test-csm.fs0ciety.org";
// Popup : réglages (URL CSM, jeton de connecteur, auto + période), choix du jour, bouton de synchro manuelle.
// Il parle au content script de l'onglet DICOS actif (statut + synchro) ; l'envoi vers CSM passe par le service worker.
const $ = (id) => document.getElementById(id);
const DICOS = /^https:\/\/dicos\.intern-belgiantrain\.be\//;

function today() {
  try {
    return new Intl.DateTimeFormat("en-CA", {
      timeZone: "Europe/Brussels",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    }).format(new Date());
  } catch (_) {
    const d = new Date();
    const p = (x) => String(x).padStart(2, "0");
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  }
}

function setStatus(html, cls) {
  $("status").className = "status" + (cls ? " " + cls : "");
  $("status").innerHTML = html;
}
function setHint(text, cls) {
  $("hint").className = "hint" + (cls ? " " + cls : "");
  $("hint").textContent = text || "";
}

async function activeDicosTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab && DICOS.test(tab.url || "") ? tab : null;
}

function fmtResult(r) {
  if (!r) return "Aucune synchro récente.";
  if (r.error) return `<span class="err">${escapeHtml(String(r.error))}</span>`;
  // Les valeurs viennent d'une réponse réseau : tout est coercé/échappé avant innerHTML (jamais de HTML injecté).
  const num = (v) => Number(v) || 0;
  const when = r.at ? ` · ${new Date(r.at).toLocaleTimeString("fr-BE", { hour: "2-digit", minute: "2-digit" })}` : "";
  const found = num(r.found ?? r.received);
  // r.days > 1 : synchro de plusieurs jours (totaux cumulés).
  return `<span class="ok">✓ ${escapeHtml(String(r.day || ""))}${escapeHtml(when)}</span><br>${found} mission(s) PMR → ${num(r.received)} trajet(s)${r.dossiers ? ` · ${num(r.dossiers)} dossier(s)` : ""} · <b>${num(r.created)}</b> créée(s), <b>${num(r.updated)}</b> maj, ${num(r.skipped)} ignorée(s)${
    r.groups ? `<br>Groupes : ${num(r.groups.received)} trajet(s) · <b>${num(r.groups.created)}</b> créé(s), <b>${num(r.groups.updated)}</b> maj` : ""
  }${fmtPending(r.pending)}${fmtAtms(r.atms)}${fmtMode(r)}`;
}
// Dossiers « à vérifier » (planificateur PMR, 1.9.0) : dossiers en attente d'acceptation envoyés à CSM.
function fmtPending(p) {
  if (!p) return "";
  const num = (v) => Number(v) || 0;
  const line = `<br>Dossiers en attente : ${num(p.found)} dossier(s) → <b>${num(p.created)}</b> tâche(s) créée(s), <b>${num(p.updated)}</b> maj`;
  return p.error ? `${line} · <span class="err">${escapeHtml(String(p.error))}</span>` : line;
}
// Temps d'arrêt ATMS (export ALEA) : trains lus dans l'onglet ATMS ; sans onglet, CSM utilise iRail.
function fmtAtms(a) {
  if (!a || !(Number(a.requested) > 0)) return "";
  const num = (v) => Number(v) || 0;
  const via = a.via === "onglet" ? " (onglet ATMS)" : a.via === "direct" ? " (lecture directe)" : "";
  const line = `<br>Temps d'arrêt ATMS : <b>${num(a.stored)}</b> / ${num(a.requested)} train(s)${via}${
    num(a.failed) ? ` · ${num(a.failed)} introuvable(s)` : ""
  }`;
  return a.error ? `${line} · <span class="err">${escapeHtml(String(a.error))}</span>` : line;
}
// Mode de lecture : dossiers complets (trip-details) ou repli sur l'ancien format, avec les chemins essayés.
function fmtMode(r) {
  if (r.mode !== "missions") return "";
  const tries = Array.isArray(r.tripDiag) ? r.tripDiag.slice(0, 12) : [];
  // Mode normal depuis 1.4 (liste + détail regroupés en trajets) : rien à signaler sans essai trip-details raté.
  if (!tries.length) return "";
  const list = tries
    .map((t) => `${escapeHtml(String((t && t.path) || ""))} → ${escapeHtml(String((t && t.why) || ""))}`)
    .join("<br>");
  return `<br><span class="err">Dossiers complets indisponibles : trajets reconstruits depuis la liste.</span>${list ? `<br><small>${list}</small>` : ""}`;
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
}

async function refreshStatus() {
  const tab = await activeDicosTab();
  if (!tab) {
    $("dot").classList.remove("on");
    setHint("Ouvre l'onglet DICOS (dicos.intern-belgiantrain.be) pour synchroniser.", "err");
    $("sync").disabled = true;
    return;
  }
  $("sync").disabled = false;
  try {
    const s = await chrome.tabs.sendMessage(tab.id, { cmd: "status" });
    if (s && s.hasToken) {
      $("dot").classList.add("on");
      setHint(`Session DICOS détectée · ${s.stationCount} gare(s) au périmètre.`);
    } else {
      $("dot").classList.remove("on");
      setHint("Session pas encore détectée : navigue dans les missions DICOS une fois.", "err");
    }
  } catch (_) {
    $("dot").classList.remove("on");
    setHint("Recharge l'onglet DICOS après avoir installé l'extension.", "err");
  }
}

async function load() {
  const v = await chrome.storage.local.get(["csmUrl", "token", "auto", "last"]);
  // Adresse CSM pré-remplie (le texte gris n'était qu'un exemple, le champ restait vide).
  $("csmUrl").value = v.csmUrl || DEFAULT_CSM_URL;
  $("token").value = v.token || "";
  $("auto").checked = !!(v.auto && v.auto.enabled);
  $("minutes").value = (v.auto && v.auto.minutes) || 10;
  $("day").value = today();
  setStatus(fmtResult(v.last));
  refreshStatus();
}

$("save").addEventListener("click", async () => {
  let csmUrl = $("csmUrl").value.trim().replace(/\/+$/, "");
  // Tolérant : si l'URL est saisie sans schéma (ex. « test-csm.fs0ciety.org »), on préfixe https:// .
  if (csmUrl && !/^https?:\/\//i.test(csmUrl)) csmUrl = "https://" + csmUrl;
  $("csmUrl").value = csmUrl;
  const token = $("token").value.trim();
  const auto = { enabled: $("auto").checked, minutes: Math.max(2, Math.min(120, Number($("minutes").value) || 10)) };
  if (!csmUrl || !token) {
    setHint("Renseigne l'URL CSM ET le jeton avant d'enregistrer.", "err");
    return;
  }
  if (csmUrl) {
    let origin;
    try {
      origin = new URL(csmUrl).origin + "/*";
    } catch (_) {
      setHint("URL CSM invalide.", "err");
      return;
    }
    // Permission d'hôte pour l'appel cross-origin vers CSM (demandée sur geste utilisateur).
    try {
      const granted = await chrome.permissions.request({ origins: [origin] });
      if (!granted) {
        setHint("Permission refusée pour l'URL CSM : la synchro ne pourra pas envoyer.", "err");
      }
    } catch (_) {}
  }
  await chrome.storage.local.set({ csmUrl, token, auto });
  setHint("Réglages enregistrés.", "ok");
});

$("sync").addEventListener("click", async () => {
  const tab = await activeDicosTab();
  if (!tab) return;
  // Pré-contrôle : sans URL + jeton enregistrés, l'envoi vers CSM échouera → message clair plutôt que « Configure… ».
  const cfg = await chrome.storage.local.get(["csmUrl", "token"]);
  if (!cfg.csmUrl || !cfg.token) {
    setStatus('<span class="err">Enregistre d\'abord l\'URL CSM et le jeton (bouton « Enregistrer les réglages »).</span>');
    return;
  }
  $("sync").disabled = true;
  setStatus("Synchronisation en cours…");
  try {
    const r = await chrome.tabs.sendMessage(tab.id, {
      cmd: "sync",
      day: $("day").value || today(),
      days: Number($("days").value) || 1,
    });
    if (r && r.busy) {
      // Une synchro (manuelle ou automatique) tourne déjà : on affiche son avancement plutôt qu'une erreur.
      const v = await chrome.storage.local.get(["progress"]);
      setStatus(v.progress ? fmtProgress(v.progress) : "Synchronisation déjà en cours…");
    } else setStatus(fmtResult(r), r && r.error ? "" : "");
  } catch (_) {
    setStatus('<span class="err">Content script indisponible : recharge l\'onglet DICOS.</span>');
  } finally {
    $("sync").disabled = false;
    refreshStatus();
  }
});

load();

// Version installée (pour vérifier que la mise à jour a bien été chargée).
try {
  document.getElementById("ver").textContent = "v" + chrome.runtime.getManifest().version;
} catch (_) {}

// Avancement en direct de la synchro (écrit par le content script).
function fmtProgress(p) {
  const n = (v) => Number(v) || 0;
  const secs = p.startedAt ? Math.max(0, Math.round((Date.now() - n(p.startedAt)) / 1000)) : 0;
  const count = n(p.total) ? ` : <b>${n(p.done)}</b> / ${n(p.total)}` : "…";
  const pct = n(p.total) ? Math.round((100 * n(p.done)) / n(p.total)) : 0;
  return `⏳ ${escapeHtml(String(p.day || ""))} · ${escapeHtml(String(p.phase || ""))}${count}${secs ? ` · ${secs} s` : ""}` +
    (n(p.total) ? `<br><progress max="100" value="${pct}" style="width:100%"></progress>` : "");
}
try {
  chrome.storage.local.get(["progress"]).then((v) => {
    if (v.progress) setStatus(fmtProgress(v.progress));
  });
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area !== "local") return;
    if (ch.progress && ch.progress.newValue) setStatus(fmtProgress(ch.progress.newValue));
    else if (ch.last && ch.last.newValue) setStatus(fmtResult(ch.last.newValue));
  });
} catch (_) {}

// --- 1.7.0 : connexion depuis CSM, autorisation d'envoi, mise à jour disponible ---
const VERSION = chrome.runtime.getManifest().version;
function newer(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  for (let i = 0; i < 3; i++) if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  return false;
}
async function csmOrigin() {
  const v = await chrome.storage.local.get(["csmUrl"]);
  try {
    return new URL(v.csmUrl || DEFAULT_CSM_URL).origin;
  } catch (_) {
    return new URL(DEFAULT_CSM_URL).origin;
  }
}
async function openExtensionPage() {
  chrome.tabs.create({ url: (await csmOrigin()) + "/pmr/extension" });
}
async function refreshNotices() {
  const v = await chrome.storage.local.get(["csmUrl", "token", "latest"]);
  const origin = await csmOrigin();
  let allowed = false;
  try {
    allowed = await chrome.permissions.contains({ origins: [origin + "/*"] });
  } catch (_) {}
  $("connectBox").hidden = Boolean(v.token);
  $("allowBox").hidden = !v.token || allowed;
  const latest = typeof v.latest === "string" ? v.latest : "";
  $("update").hidden = !(latest && newer(latest, VERSION));
  $("updateText").textContent = `Nouvelle version ${latest} disponible (installée : ${VERSION}).`;
}
$("allow").addEventListener("click", async () => {
  try {
    const ok = await chrome.permissions.request({ origins: [(await csmOrigin()) + "/*"] });
    setHint(ok ? "Envoi vers CSM autorisé." : "Autorisation refusée : la synchro ne pourra pas envoyer.", ok ? "ok" : "err");
  } catch (_) {
    setHint("Autorisation impossible : vérifie l'URL CSM.", "err");
  }
  refreshNotices();
});
$("openCsm").addEventListener("click", openExtensionPage);
$("openCsm2").addEventListener("click", openExtensionPage);
refreshNotices();
try {
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && (ch.token || ch.csmUrl || ch.latest)) {
      refreshNotices();
      if (ch.token || ch.csmUrl) load();
    }
  });
} catch (_) {}

// --- 1.8.0 : horaires Quinyx (Équipe › Planning de CSM) ---
function fmtQuinyx(r) {
  if (!r) return "Aucune synchro Quinyx récente.";
  const num = (v) => Number(v) || 0;
  const when = r.at ? new Date(r.at).toLocaleString("fr-BE", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) : "";
  if (r.error) return `<span class="err">${escapeHtml(String(r.error))}</span>${when ? `<br><small>${escapeHtml(when)}</small>` : ""}`;
  const lines = (Array.isArray(r.groups) ? r.groups : []).slice(0, 20).map((g) =>
    g && g.error
      ? `${escapeHtml(String(g.label || "Groupe"))} : <span class="err">${escapeHtml(String(g.error))}</span>`
      : `${escapeHtml(String((g && g.label) || "Groupe"))} : <b>${num(g.kept)}</b> prestation(s) jusqu'au ${escapeHtml(String((g && g.to) || ""))} · ${num(g.created)} nouvelle(s), ${num(g.updated)} maj, ${num(g.removed)} retirée(s)${num(g.notTeam) ? ` · ${num(g.notTeam)} hors équipe CSM` : ""}${
          num(g.failed) ? ` · <span class="err">${num(g.failed)} en échec, resynchronise</span>` : ""
        }${g.removalSkipped ? ` · <span class="err">retraits suspendus (lot partiel)</span>` : ""}`,
  );
  return `<span class="ok">✓ ${escapeHtml(when)}</span><br>${lines.join("<br>") || "Aucun groupe lu."}`;
}
function setQuinyx(html) {
  $("quinyxStatus").innerHTML = html;
}
chrome.storage.local.get(["quinyxLast"]).then((v) => setQuinyx(fmtQuinyx(v.quinyxLast)));
$("quinyxSync").addEventListener("click", async () => {
  $("quinyxSync").disabled = true;
  setQuinyx("Lecture du planning Quinyx…");
  try {
    setQuinyx(fmtQuinyx(await chrome.runtime.sendMessage({ cmd: "quinyx" })));
  } catch (_) {
    setQuinyx('<span class="err">Extension indisponible : réessaie.</span>');
  } finally {
    $("quinyxSync").disabled = false;
  }
});
try {
  chrome.storage.onChanged.addListener((ch, area) => {
    if (area === "local" && ch.quinyxLast && ch.quinyxLast.newValue) setQuinyx(fmtQuinyx(ch.quinyxLast.newValue));
  });
} catch (_) {}
